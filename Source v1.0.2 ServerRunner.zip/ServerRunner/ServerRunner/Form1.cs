﻿using System;
using System.Diagnostics;
using System.IO;
using System.Windows.Forms;
namespace ServerRunner
{
    public partial class Form1 : Form
    {
        private string basePath;
        public Form1()
        {
            InitializeComponent();
            basePath = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),
                ".server"
            );
            LoadFolders();
        }
        private void LoadFolders()
        {
            listBox1.Items.Clear();
            if (!Directory.Exists(basePath))
                return;
            foreach (var dir in Directory.GetDirectories(basePath))
            {
                string startBat = Path.Combine(dir, "start.bat");
                string runBat = Path.Combine(dir, "run.bat");
                if (File.Exists(startBat) || File.Exists(runBat))
                {
                    string folderName = Path.GetFileName(dir);
                    listBox1.Items.Add(new ListViewItemWrapper(folderName, dir));
                }
            }
        }
        private void listBox1_DoubleClick(object sender, EventArgs e)
        {
            if (listBox1.SelectedItem == null) return;
            var wrapper = listBox1.SelectedItem as ListViewItemWrapper;
            string dir = wrapper?.FullPath;
            if (dir == null) return;
            string startBat = Path.Combine(dir, "start.bat");
            string runBat = Path.Combine(dir, "run.bat");
            string fileToRun = File.Exists(startBat) ? startBat :
                               File.Exists(runBat) ? runBat : null;
            if (fileToRun != null)
            {
                try
                {
                    Process.Start(new ProcessStartInfo
                    {
                        FileName = fileToRun,
                        WorkingDirectory = dir,
                        UseShellExecute = true
                    });
                }
                catch { }
            }
        }
        private void guna2CircleButton1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
        }
        private void guna2Panel1_Paint(object sender, PaintEventArgs e)
        {
        }
        private void guna2CircleButton1_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }
    }
    class ListViewItemWrapper
    {
        public string Display { get; set; }
        public string FullPath { get; set; }
        public ListViewItemWrapper(string display, string fullPath)
        {
            Display = display;
            FullPath = fullPath;
        }
        public override string ToString()
        {
            return Display;
        }
    }
}